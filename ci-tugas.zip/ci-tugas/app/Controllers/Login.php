<?php 
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\Auth_model;

class Login extends Controller
{
    
    public function __construct()
    {
        $this->auth = new Auth_model();

    }   

    public function index()
    {
	    
		return view('login_view');
    }


    public function proses()
    {
        $username = htmlspecialchars($this->request->getPost('username'));
        $password = htmlspecialchars($this->request->getPost('password'));

        $cek_login = $this->auth->cek_login($username);
    
        if (password_verify($password, $cek_login['password'])) {
            session()->set("id", $cek_login['id']);
            session()->set("password", $cek_login['password']);
            session()->set("username", $cek_login['username']);
            session()->set("nama", $cek_login['nama']);

            return redirect()->to('/Login');
        } else {
            return redirect()->to('/Product');
        }

    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
    
}

?>